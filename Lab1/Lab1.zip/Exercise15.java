import javax.swing.*;
import java.awt.*;

public class Exercise15 {
    static class circleIcon implements Icon {
        private Color c;
        private int size;

        public circleIcon(Color c) {
            this.c = c;
            this.size = 150;
        }

        public int getIconWidth() {
            return size;
        }

        public int getIconHeight() {
            return size;
        }

        public void paintIcon(Component comp, Graphics grap, int x, int y) {
            grap.setColor(c);
            grap.fillOval(x, y, size, size);
        }
    }

    static private void updateLabel(Color color, JLabel label, JFrame window) {
        label.setIcon(new circleIcon(color));
        window.repaint();
    }


    public static void main(String[] args) {
        JFrame window = new JFrame();

        circleIcon circle_icon = new circleIcon(Color.RED);
        JLabel circle = new JLabel(circle_icon);
        window.add(circle, BorderLayout.CENTER);

        JButton redButton = new JButton("Red");
        JButton greenButton = new JButton("Green");
        JButton blueButton = new JButton("Blue");

        window.add(redButton);
        window.add(greenButton);
        window.add(blueButton);
      
        redButton.addActionListener(event -> updateLabel(Color.RED, circle, window));
        greenButton.addActionListener(event -> updateLabel(Color.GREEN, circle, window));
        blueButton.addActionListener(event -> updateLabel(Color.BLUE, circle, window));
        

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(400, 400);
        window.setLayout(new FlowLayout());
        window.pack();
        window.setVisible(true);
    }
    
}
