public interface Filter
{
boolean accept(String x);
}