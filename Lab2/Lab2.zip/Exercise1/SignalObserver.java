package Exercise1;

public interface SignalObserver {
	public void updateSignal(double value);
}
