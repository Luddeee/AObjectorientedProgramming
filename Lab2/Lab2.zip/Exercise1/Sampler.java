package Exercise1;

public interface Sampler {
	public double read();
}
